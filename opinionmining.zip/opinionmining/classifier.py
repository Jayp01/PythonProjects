import nltk
import ast
from nltk.tokenize import word_tokenize
def classify(inp,outp):
	inF = open(inp,"r").read()
	outF=open (outp,"w")
	words=ast.literal_eval(inF)
	outputData={}
	for x,y in words.items():
		outputData[x]=nltk.pos_tag(nltk.word_tokenize(y))
	for x,y in outputData.items():
		print(x,' ',y)
	outF.write(str(outputData))
	outF.close()

