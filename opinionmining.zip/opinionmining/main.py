import prepro
import tokenize
import classifier
import aspects
import opinions

import subprocess
tmp = subprocess.call('clear',shell=True)
'''
while True:
	example=int(input("example(1/2):"))
	if example== 1 or example== 2:
		break
	else:
		continue
'''
Addr='Dataset/sample2'+'/'
_Dataset=Addr+'a.Dataset.txt'
_PreProcess=Addr+'b.PreProcess.txt'
_Tokenize=Addr+'c.Tokenize.txt'
_Pos=Addr+'d.Pos.txt'
_Aspects=Addr+'e.Aspects.txt'
_Opinions=Addr+'f.Opinions.txt'
 
print("\t******OPINION MINING ON A DATASET******\t")
ch=0
while ch!=6:
	ch=int(input('\nChoose operation to be performed on the dataset available:\n\t1.Data Preprocessing\n\t2.Data Tokenization\n\t3.Parts of Speech of tokens\n\t4.Aspect Listing\n\t5.Opinion Listing\n\t6.Exit\nChoice: '))
	if ch==1:
		prepro.preprocess(_Dataset,_PreProcess)
	elif ch==2:
		tokenize.sentencetoken(_PreProcess,_Tokenize)
	elif ch==3:
		classifier.classify(_Tokenize,_Pos)
	elif ch==4:
		aspects.extractasp(_Pos,_Aspects)
	elif ch==5:
		opinions.opWords(_Pos,_Aspects,_Opinions)
	elif ch==6:
		continue
	else:
		print('Invalid choice!please enter a valid choice:')
