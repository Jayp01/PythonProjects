import nltk
nltk.download('stopwords')
def preprocess(inp,outp):
	inF = open(inp,"r").read()
	outF=open (outp,"w+")
	Stop_words = nltk.corpus.stopwords.words("english")
	filtered_data=(' '.join([x for x in inF.split() if x not in Stop_words]))
	print('\nThe standard Stop Words are:\n')
	print(Stop_words)
	print('\nThe dataset after pre-processing-\n')
	print(str(filtered_data))
	outF.write(str(filtered_data))
	outF.close()
