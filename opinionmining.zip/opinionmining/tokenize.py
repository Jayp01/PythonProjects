import nltk
#nltk.download('stopwords')
#nltk.download('punkt')
def sentencetoken(inp,outp):
	tokens={}
	inF = open(inp,"r").read()
	outF = open (outp,"w")
	tk = nltk.tokenize.punkt.PunktSentenceTokenizer()
	count=1;
	for token in tk.tokenize(inF):      
		tokens[count]=token
		count+=1
	outF.write(str(tokens))
	for key,value in tokens.items():
		print(key,' ',value)
	outF.close()

